<template>
  <div class="hero">
    <div class="hero_block_left">
      <div class="title_hero">
        <h1>
          Bar. <br />
          Restaurant. <br />
          Afterwork. <span class="none">la teste de buch</span>
        </h1>
      </div>
      <div class="content_hero">
        <p>
          Venez découvrir une sélection de plus de 60 Bières, Vins et Cocktails,
          dans une ambiance chaleureuse et laissez vous tenter par notre offre
          gourmande de restauration.
          <span class="yellow"></span>
        </p>
        <div class="carte">
          <a href="/carte_angels_pub.pdf" target="_blank"
            >Découvrir la carte</a
          >
        </div>
      </div>
    </div>
    <div class="hero_block_right">
      <div class="img-first">
        <img src="~assets/img/png/ap-min.png" alt="" />
      </div>
      <div class="img-second">
        <img src="~assets/img/png/bee.png" alt="" />
      </div>
      <div class="corner">
        <img src="~assets/img/svg/corner.svg" alt="" />
      </div>
      <div class="hand">
        <img src="~assets/img/svg/gum.svg" alt="" />
      </div>

      <div class="tele">
        <img src="~assets/img/svg/tele.svg" alt="" />
      </div>
      <div class="eyes">
        <img src="~assets/img/svg/eyes.svg" alt="" />
      </div>
      <div class="stones">
        <img src="~assets/img/svg/stones.svg" alt="" />
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios'
export default {
  data() {
    return {
      form: {
        email: '',
      },
      error: [],
      sucess: false,
    }
  },
  methods: {
    submit(e) {
      e.preventDefault()
      this.$axios
        .post('https://api.angels-pub.fr/subscribe', { ...this.form })
        .then((res) =>
          (this.form = '')((this.sucess = true))((this.error = false))
        )
        .catch(e)
      //   this.error = true
    },
  },
}
</script>

<style>
a {
  text-decoration: none;
  color: var(--black);
}
.hero {
  text-align: left;
  display: flex;
  flex-flow: row wrap;
  margin: auto;
  align-items: center;
  width: 100%;
  padding: 0 15px 0 15px;
  justify-content: space-between;
}

.hero_block_left {
  width: 100%;
}

.title_hero h1 {
  line-height: 56px;
  opacity: 0;
  font-size: 52px;
  color: var(--yellow);
  animation: appear 0.9s cubic-bezier(0.25, 0.46, 0.45, 0.94);
  animation-fill-mode: forwards;
  animation-delay: 1.9s;
}

@keyframes appear {
  from {
    opacity: 0;
    transform: translateY(15px);
  }
  to {
    opacity: 1;
    transform: translateY(0px);
  }
}

.carte {
  margin-top: 30px;
}

.carte a {
  color: var(--black);
  background-color: var(--yellow);
  padding: 14px 20px;
  animation: appear 0.9s cubic-bezier(0.25, 0.46, 0.45, 0.94);
  animation-fill-mode: forwards;
  animation-delay: 2.1s;
  font-weight: 900;
  opacity: 0;
  border-radius: 6px;
  transition: all 0.3s;
}

.carte a:hover {
  color: var(--yellow);
  background-color: var(--black);
}

.none {
  display: none;
}

.yellow {
  color: var(--yellow);
  font-weight: 800;
}

.content_hero {
  padding: 20px 0px 30px 0px;
  position: relative;
}

.content_hero p {
  opacity: 0;
  animation: appear 0.9s cubic-bezier(0.25, 0.46, 0.45, 0.94);
  animation-fill-mode: forwards;
  animation-delay: 2.1s;
  font-weight: 500;
  letter-spacing: 0.5px;
  line-height: 24px;
}

.arrow {
  opacity: 0;
  animation: appear 0.9s cubic-bezier(0.25, 0.46, 0.45, 0.94);
  animation-fill-mode: forwards;
  animation-delay: 2.2s;
}

.arrow img {
  width: 45px;
  transform: rotate(40deg);
  position: absolute;
  right: 5%;
  bottom: -45px;
}

.input_hero {
  width: 100%;
  opacity: 0;
  animation: appear 0.9s cubic-bezier(0.25, 0.46, 0.45, 0.94);
  animation-fill-mode: forwards;
  animation-delay: 2.3s;
  margin-bottom: 10px;
  margin-top: 25px;
}

.input_hero input {
  padding: 20px 10px;
  width: 70%;

  outline: none;
  font-family: RobotoMono;
  border: none;
  font-size: 16px;

  background-color: var(--input);
  color: var(--white);
  cursor: url('~assets/img/svg/mouse-ap.svg'), auto;
  border-radius: 3px;
}

.input_hero input::placeholder {
  outline: none;
  font-family: RobotoMono;
  border: none;
  opacity: 0.3;
  font-size: 14px;
  color: var(--white);
  border-radius: 0px;
}

.input_hero button {
  padding: 20px 10px;
  width: 20%;
  border: none;
  background-color: var(--black);
  cursor: url('~assets/img/svg/mouse-ap.svg'), auto;
  border-radius: 3px;
  font-size: 16px;
  color: var(--yellow);
  transition: all 0.5s;
  font-family: RecoletaBold;
}

.input_hero button:hover {
  background-color: var(--yellow);
  color: var(--black);
  cursor: url('~assets/img/svg/mouse-ap.svg'), auto;
  transform: rotate(360deg);
}

.img img {
  width: 100%;
}

.hero_block_right {
  position: relative;
  opacity: 0;
  animation: appear 0.9s cubic-bezier(0.25, 0.46, 0.45, 0.94);
  animation-fill-mode: forwards;
  animation-delay: 2.4s;
  margin-top: 30px;
  display: flex;
  overflow-x: hidden;
  margin-left: 15px;
  flex-flow: row nowrap;
}

.img-first img {
  width: 120%;
  margin-top: 30px;
}
.img-second img {
  margin-top: 50px;
  width: 120%;
  margin-left: -50px;
}

.corner img {
  position: absolute;
  top: 0;
  left: 0;
  width: 80px;
}

.hand img {
  position: absolute;
  bottom: 0;
  left: 0;
  width: 60px;
}

.tele img {
  position: absolute;
  top: 0;
  right: 0;
  width: 80px;
}

.eyes img {
  position: absolute;
  bottom: 0;
  right: 0;
  width: 60px;
}

.stones img {
  position: absolute;
  top: 40%;
  right: 40%;
  width: 120px;
}

@media screen and (min-width: 768px) {
}

@media screen and (min-width: 1024px) {
  .hero_block_left {
    width: 45%;
  }

  .hero_block_right {
    width: 50%;
  }

  .title_hero h1 {
    line-height: 60px;
    font-size: 50px;
    color: var(--yellow);
    margin-bottom: 20px;
  }

  .content_hero p {
    font-weight: 200;
    font-size: 14px;
    line-height: 26px;
  }

  .arrow img {
    width: 45px;
    transform: rotate(60deg);
    position: absolute;
    right: 5%;
    bottom: -45px;
  }

  .corner img {
    position: absolute;
    top: 0;
    left: 0;
    width: 80px;
  }

  .hand img {
    position: absolute;
    bottom: 0;
    left: 10%;
    width: 60px;
  }

  .tele img {
    position: absolute;
    top: 0;
    right: 0;
    width: 80px;
  }

  .eyes img {
    position: absolute;
    bottom: 20px;
    right: 10%;
    width: 60px;
  }

  .stones img {
    position: absolute;
    top: 40%;
    right: 40%;
    width: 120px;
  }

  .img-first img {
    width: 100%;
    margin-top: 10px;
    margin-left: 40px;
  }
  .img-second img {
    margin-top: 10px;
    width: 120%;
  }
}

@media screen and (min-width: 1200px) {
  .hero_block_left {
    width: 43%;
    margin-top: 30px;
  }

  .hero_block_right {
    width: 50%;
  }

  .title_hero h1 {
    line-height: 70px;
    font-size: 60px;
    color: var(--yellow);
    margin-bottom: 20px;
  }

  .arrow img {
    width: 45px;
    transform: rotate(60deg);
    position: absolute;
    right: 22%;
    bottom: -45px;
  }

  .carte a {
    font-size: 16px;
  }

  .content_hero p {
    font-weight: 200;
    font-size: 16px;
    line-height: 32px;
  }

  .img-first img {
    width: 100%;
    margin-top: 10px;
    margin-left: 40px;
  }
  .img-second img {
    margin-top: 10px;
    width: 110%;
  }

  .sucess {
    font-size: 18px;
  }

  .corner img {
    position: absolute;
    top: 0;
    left: 0;
    width: 120px;
  }

  .hand img {
    position: absolute;
    bottom: 0;
    left: 50px;
    width: 80px;
  }

  .tele img {
    position: absolute;
    top: 0;
    right: 0;
    width: 120px;
  }

  .eyes img {
    position: absolute;
    bottom: 30px;
    right: 50px;
    width: 80px;
  }

  .stones img {
    position: absolute;
    top: 40%;
    right: 45%;
    width: 160px;
  }
}

@media screen and (min-width: 1440px) {
  .hero_block_left {
    width: 45%;
  }

  .hero_block_right {
    width: 50%;
  }

  .title_hero h1 {
    line-height: 100px;
    font-size: 100px;
    color: var(--yellow);
    margin-bottom: 20px;
  }

  .arrow img {
    width: 65px;
    transform: rotate(60deg);
    position: absolute;
    right: 37%;
    bottom: -45px;
  }

  .content_hero p {
    font-weight: 300;
    font-size: 20px;
    width: 650px;
    line-height: 38px;
  }

  .img-first img {
    width: 100%;
    margin-top: 30px;
    margin-left: 40px;
  }
  .img-second img {
    margin-top: 10px;
    width: 110%;
  }

  .corner img {
    position: absolute;
    top: 0;
    left: 0;
    width: 180px;
  }

  .hand img {
    position: absolute;
    bottom: 0;
    left: 50px;
    width: 120px;
  }

  .tele img {
    position: absolute;
    top: 0;
    right: 0;
    width: 180px;
  }

  .eyes img {
    position: absolute;
    bottom: 50px;
    right: 100px;
    width: 160px;
  }

  .stones img {
    position: absolute;
    top: 40%;
    right: 45%;
    width: 220px;
  }
  .input_hero {
    margin-top: 30px;
  }

  .input_hero input {
    padding: 20px 40px;
  }

  .input_hero button {
    padding: 20px 40px;
  }
}
</style>
